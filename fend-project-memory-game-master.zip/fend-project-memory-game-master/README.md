# Memory Game Project

Udacity Front-End Developer Nanodegree secoend Project. Try to test 
your memory by memorize the location of different cards.

## Table of Contents

* What the game is about.
* How to play the game.
* how to daownload the game and install game.
* Dependencies of the game.
* Code acknowledgements.


## What the game is about

The main concept of game to try to memorize the location of different cards.When
the player flip one card should remember where is the matched card.

## How to play the game

The game have bored with sixteen cards and eight different pairs shapes that randomly arranged.
All cards flip the shape down. The player should open two fliped cards at a time to locate the ones that match.
when the player start first flip:

 * Time start in secoend.
 * Moves start each 10 moves will loose one star.
```python
 Win :

 * Match all cards with maximum 29 moves.

 Failed:

* Run out of 30 moves. 
```
The player can reset the game anytime want. 

## how to daownload the game and install game

* Download the zip file.
* open index file in your Browser.

## Dependencies of the game

* Icons from [fontawesome](https://fontawesome.com/v4.7.0/icons/)
* Background []('../img/geometry2.png')
* [font](https://fonts.google.com/specimen/Coda?selection.family=Coda&query=coda)

## Code acknowledgements

* Shuffle function from [stackoverflow](https://stackoverflow.com/questions/2450954/how-to-randomize-shuffle-a-javascript-array/2450976#2450976).
